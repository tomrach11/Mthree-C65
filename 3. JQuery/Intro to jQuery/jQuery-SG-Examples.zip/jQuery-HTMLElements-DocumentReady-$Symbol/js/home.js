$(document).ready(function(){
    alert("Ready to go!!!");
})
