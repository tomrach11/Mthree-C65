$(document).ready(function(){
    // remove a class from an element
    $("#first").removeClass("text-center");
    // add two classes to an element
    $("#newButton").addClass("btn btn-default");
    // create a new HTML element
    $("#emptyDiv").append("p").text("A new paragraph of text...");
    // set a CSS style on an element
    $("#first").css("color", "blue");
    
})
