package com.tr.classroster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassrosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
